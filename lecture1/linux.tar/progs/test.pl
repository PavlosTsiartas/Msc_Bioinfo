#!/usr/bin/perl

print "Hello world\n";
$line = <STDIN>;

exit(0);

